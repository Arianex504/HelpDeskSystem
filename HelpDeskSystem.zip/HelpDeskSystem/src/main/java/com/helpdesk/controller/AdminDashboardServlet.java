package com.helpdesk.controller;

import com.helpdesk.dao.TicketDAO;
import com.helpdesk.model.Ticket;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/adminDashboard")
public class AdminDashboardServlet extends HttpServlet {
    private TicketDAO ticketDAO = new TicketDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Map<String, Integer> ticketCounts = new HashMap<>();
        ticketCounts.put("open", ticketDAO.countByStatus("open"));
        ticketCounts.put("inProgress", ticketDAO.countByStatus("in_progress"));
        ticketCounts.put("resolved", ticketDAO.countByStatus("resolved"));
        ticketCounts.put("closed", ticketDAO.countByStatus("closed"));

        request.setAttribute("ticketCounts", ticketCounts);
        request.setAttribute("tickets", ticketDAO.getAllTickets());

        // 🔹 Asegúrate de que aquí diga esto:
        RequestDispatcher dispatcher = request.getRequestDispatcher("adminDashboard.jsp");
        dispatcher.forward(request, response);
    }
}

