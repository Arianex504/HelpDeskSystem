package com.helpdesk.controller;

import com.helpdesk.dao.TicketDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/updateStatus")
public class UpdateStatusServlet extends HttpServlet {

    private TicketDAO ticketDAO;

    @Override
    public void init() {
        ticketDAO = new TicketDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int ticketId = Integer.parseInt(request.getParameter("ticketId"));
            String newStatus = request.getParameter("status");

            boolean updated = ticketDAO.updateTicketStatus(ticketId, newStatus);

            if (updated) {
                // Redirige al dashboard de admin para mostrar los nuevos conteos
                response.sendRedirect("adminDashboard");
            } else {
                response.getWriter().println("Error al actualizar el estado del ticket.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
