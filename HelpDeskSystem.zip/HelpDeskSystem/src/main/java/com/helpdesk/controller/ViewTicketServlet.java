package com.helpdesk.controller;

import java.io.IOException;

import com.helpdesk.dao.TicketDAO;
import com.helpdesk.model.Ticket;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/viewTicket")
public class ViewTicketServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private TicketDAO ticketDAO;

    @Override
    public void init() {
        ticketDAO = new TicketDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Se obtiene el ticket ID del parámetro de la URL
        int ticketId = Integer.parseInt(request.getParameter("id"));

        //Se usa el DAO para adquirir los detalles del ticket del database
        Ticket ticket = ticketDAO.getTicketById(ticketId);

        // Almacena el objeto del ticket en la solicitud para que el JSP pueda acceder a él
        request.setAttribute("ticket", ticket);

        //Reenviar la solicitud a la página de detalles para que se muestre
        request.getRequestDispatcher("view_ticket_admin.jsp").forward(request, response);
    }
}